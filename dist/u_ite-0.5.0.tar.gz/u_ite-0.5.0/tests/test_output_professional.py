"""
Test suite to verify no emojis appear in CLI output.
Run with: pytest tests/test_output_professional.py -v
"""

import pytest
import subprocess
import re
from pathlib import Path

# List of emoji Unicode ranges to check for
EMOJI_PATTERN = re.compile(
    '[' 
    '\U0001F300-\U0001F64F'  # Misc symbols and pictographs
    '\U0001F680-\U0001F6FF'  # Transport and map symbols
    '\U0001F700-\U0001F77F'  # Alchemical symbols
    '\U0001F780-\U0001F7FF'  # Geometric shapes
    '\U0001F800-\U0001F8FF'  # Supplemental arrows
    '\U0001F900-\U0001F9FF'  # Supplemental symbols
    '\U0001FA00-\U0001FA6F'  # Chess symbols
    '\U0001FA70-\U0001FAFF'  # Symbols and pictographs extended
    '\U00002702-\U000027B0'  # Dingbats
    '\U000024C2-\U0001F251'  # Enclosed characters
    ']+', 
    flags=re.UNICODE
)

# Common emoji that might slip through
SPECIFIC_EMOJIS = ['✅', '❌', '⚠️', 'ℹ️', '📡', '📊', '🔍', '📭', 
                   '🚀', '📁', '💡', '🏆', '🔴', '🌍', '🐢', '📶']


def run_command(cmd):
    """Run a uite command and return output."""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout + result.stderr


def test_no_emojis_in_help():
    """Test that help text contains no emojis."""
    output = run_command("uite --help")
    assert not EMOJI_PATTERN.search(output), "Emojis found in help text"
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output, f"Found {emoji} in help text"


def test_no_emojis_in_network_list():
    """Test network list output."""
    output = run_command("uite network list")
    assert not EMOJI_PATTERN.search(output)
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output


def test_no_emojis_in_daemon_status():
    """Test daemon status output."""
    output = run_command("uite daemon status")
    assert not EMOJI_PATTERN.search(output)
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output


def test_no_emojis_in_history():
    """Test history command output."""
    output = run_command("uite from yesterday to today")
    assert not EMOJI_PATTERN.search(output)
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output


def test_no_emojis_in_compare_help():
    """Test compare command help."""
    output = run_command("uite compare --help")
    assert not EMOJI_PATTERN.search(output)
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output


def test_verdicts_are_professional():
    """Test that verdict strings don't contain emojis."""
    # Get actual data from database
    from uite.storage.db import HistoricalData
    runs = HistoricalData.get_runs_for_last_days("test", 1)
    for run in runs:
        verdict = run.get('verdict', '')
        assert not EMOJI_PATTERN.search(verdict)
        for emoji in SPECIFIC_EMOJIS:
            assert emoji not in verdict


def test_log_files_no_emojis():
    """Test that log files don't contain emojis."""
    log_files = [
        Path.home() / ".local/share/uite/logs/uite-observer.log",
        Path.home() / ".local/share/uite/logs/uite.log"
    ]
    
    for log_file in log_files:
        if log_file.exists():
            content = log_file.read_text()
            assert not EMOJI_PATTERN.search(content)
            for emoji in SPECIFIC_EMOJIS:
                assert emoji not in content


@pytest.mark.parametrize("command", [
    "uite network list",
    "uite daemon status",
    "uite service status",
    "uite export data --network test --format table --days 1",
])
def test_common_commands(command):
    """Test multiple commands for emoji-free output."""
    output = run_command(command)
    assert not EMOJI_PATTERN.search(output)
    for emoji in SPECIFIC_EMOJIS:
        assert emoji not in output


if __name__ == "__main__":
    # Quick manual test
    print("Running quick emoji check...")
    test_no_emojis_in_help()
    print("✅ Help text is clean")
    test_no_emojis_in_network_list()
    print("✅ Network list is clean")
    print("\nAll tests passed!")
