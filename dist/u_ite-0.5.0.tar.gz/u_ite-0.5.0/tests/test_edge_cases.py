# test_edge_cases.py
"""
Test edge cases that might still contain emojis.
"""

def test_unicode_in_error_messages():
    """Test error messages when things go wrong."""
    # Test with invalid network
    result = run_command("uite network rename invalid_id NewName")
    assert '❌' not in result
    assert '[ERROR]' in result

def test_unicode_in_offline_scenarios():
    """Test output when offline."""
    # Temporarily disconnect network
    result = run_command("uite daemon start --interval 5")
    # Should show professional offline messages
    assert '🔌' not in result
    assert '🌐' not in result

def test_database_queries():
    """Test that saved data doesn't contain emojis."""
    from uite.storage.db import HistoricalData
    runs = HistoricalData.get_runs_for_last_days("any", 30)
    for run in runs:
        if 'verdict' in run:
            assert not any(e in run['verdict'] for e in ['✅', '❌', '⚠️'])
