# Changelog

## [0.2.0] - 2026-02-23
### Added
- Complete CLI with 8 command groups
- Network profiling and tagging
- Graph generation with dark theme
- Export functionality (CSV/JSON)
- Network comparison
- Cross-platform service management
- Comprehensive documentation

### Fixed
- All import issues
- Event store integration
- Daemon startup
- Database path handling


## [0.2.1] - 2026-02-24
### Fixed
- Python 3.8-3.9 compatibility (replaced union types with Optional[])
- Cross-platform path resolution for installed packages
- Windows service error handling (no more false success messages)
- Daemon command now works correctly when installed via pip
- Added proper error messages for all platforms

### Changed
- Improved path resolution to work in both development and installed environments
- Better cross-platform log file detection

## [0.2.2] - 2026-02-24
### Fixed
- Additional Python 3.9 compatibility fixes in emitter.py
- All union types (`| None`) replaced with `Optional[]`
- Full Python 3.8-3.12 support now confirmed

## [0.2.4] - 2026-02-24
### Fixed
- Windows packet loss parsing (fixed "Loss: None%" issue)
- Quality verdicts now show correctly (Slow/Degraded/Unstable)
- Windows console encoding for emoji support
- Improved ping output parsing for all platforms

## [0.2.5] - 2026-02-24
### Fixed
- Windows packet loss parsing (fixed "Loss: None%" issue)
- Windows shutdown encoding errors
- Quality verdicts now show correctly (Slow/Degraded/Unstable)
- Enhanced emoji support on all platforms

## [0.2.6] - 2026-02-24
### Added
- Simplified health graph (Healthy vs Degraded only)
- Removed offline periods from health dashboard
- Consolidated all performance issues into "Degraded" status

### Fixed
- Final Windows shutdown encoding errors
- Added WindowsSafeHandler for console logging
- Force exit on Windows to ensure clean shutdown
- All emoji issues resolved across all platforms

## [0.2.7] - 2026-02-24
### Fixed
- Re-upload attempt for v0.2.6 (already on PyPI)
- No code changes from v0.2.6

## [0.3.0] - 2026-02-25
### Removed
- Graph generation features (unstable/removed)
- Matplotlib, numpy, and scikit-learn dependencies
- Graph CLI commands (latency, loss, health, trend)

### Changed
- Cleaner CLI with focused functionality
- Reduced package size and dependencies
- Improved stability by removing complex features

### Fixed
- Various import issues in graph module

## [0.3.1] - 2026-02-25
### Added
- `export clean` command to delete CSV files
- `daemon clear-logs` command to clear log files

### Improved
- Professional logging with CRITICAL/WARNING levels
- Clean startup messages with separator line
- Better error handling in export commands

### Fixed
- Various minor bug fixes and improvements

cat >> CHANGELOG.md << 'EOF'

## [0.3.3] - 2026-02-26
### Added
- New `uite network reset` command to completely clear all network profiles
- Backup creation before reset (saved as `.backup.TIMESTAMP`)
- Force option `--force` for automated resets

### Improved
- User-friendly network management
- Safety features with confirmation prompts
- Automatic backups for disaster recovery

## [0.3.4] - 2026-02-26
### Added
- New `uite network reset` command to completely clear all network profiles
- Automatic backup creation before reset (saved as `.backup.TIMESTAMP`)
- Force option `--force` for automated resets
- Memory cache clearing to ensure reset is immediate

### Fixed
- Reset command now properly clears in-memory cache
- Networks no longer reappear after reset
- Added verification step to confirm successful reset

## [0.4.0] - 2026-02-26
### Added
- Enhanced `uite network reset` command with options:
  - `--logs` - Also clear all daemon and service logs
  - `--all` - Nuclear option: clear networks + logs + database
- Automatic backups before reset (saved as `.backup.TIMESTAMP`)
- Better verification after reset

### Fixed
- Reset now properly clears memory cache
- Logs and database can now be reset independently

## [0.5.0] - 2026-03-03
### Added
- **Windows auto-start support** - Bundled nssm.exe eliminates manual installation
- Windows users can now run `uite service enable --auto-start` with zero setup
- New `windows_nssm.py` module for seamless Windows service management

### Changed
- **Professionalized all CLI output** - Removed all emojis throughout the codebase
- Standardized status indicators (`✅` → `[OK]`, `❌` → `[ERROR]`, etc.)
- Professional verdict messages (`🔴 No Network Connection` → `NO NETWORK CONNECTION`)
- Tips format (`💡` → `TIP:`)

### Fixed
- Windows users no longer see "nssm not found" errors
- All terminal encoding issues on Windows resolved
- Consistent output across all platforms

### Tests
- 100% test pass rate on Linux
- Windows auto-start ready for testing
